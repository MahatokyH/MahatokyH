/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  mahatoky
 * Created: 3 juin 2021
 */
create database HTSchool;
use HTSchool;
create table AdminSCH (
    idAdmin int auto_increment,
    nom varchar(50),
    mdp varchar(250),
    primary key(idAdmin)
);
create table EDT (
    idEDT int AUTO_INCREMENT,
    fileCSV varchar(20),
    primary key (idEdt)
);
create table Classe (
    idClasse int AUTO_INCREMENT,
    nom varchar(5),
    idEDT int,
    primary key(idClasse),
    foreign key(idEDT) references EDT(idEDT)
);
create table Eleve (
    idEleve int AUTO_INCREMENT,
    nom varchar(50),
    prenom varchar(50),
    Ddn date,
    sexe char(2),
    idClasse int,
    primary key(idEleve),
    foreign key(idClasse) references Classe(idClasse)
);
create table Prof (
    idProf int AUTO_INCREMENT,
    nom varchar(50),
    prenom varchar(50),
    Ddn date,
    sexe char(2),
    idClasse int,
    primary key(idProf),
    foreign key(idClasse) references Classe(idClasse)
);
create table Matiere (
    idMatiere int AUTO_INCREMENT,
    nom varchar(20),
    primary key(idMatiere)
);

create table ProfToMatiere (
    idMatiere int ,
    idProf int ,
    foreign key(idMatiere) references Matiere(idMatiere),
    foreign key(idProf) references Prof(idProf)
)
--- Admin of Application
insert into AdminSCH values (null,'SCH',sha1('JVLS2'));
insert into AdminSCH values (null,'JUL',sha1('EXTRA'));
--- EDT & CLASSE
insert into EDT values (null,'EDT_2nd.csv');
insert into Classe values (null,'2nd',1);
-- ELVE & PROF
insert into Eleve values (null,'Razafy','Jessie','2003-09-29','F',1),
    (null,'Ramanitra','Grace','2004-07-17','F',1),
    (null,'July','Chantony','2001-07-23','M',1),
    (null,'Andria','Toavina','2003-07-27','M',1),
    (null,'Rarijamiadana','Faniry','2003-08-29','M',1),
    (null,'Andriamiharisoa','Ryan','2002-05-12','M',1),
    (null,'Mizrahim','Fanantenana','2001-04-20','M',1),
    (null,'Rakotoson','Franck','2001-11-15','M',1),
    (null,'Amerella','Mahafinaritra','2002-08-19','F',1),
    (null,'Rakotohasimbola','Tsiky','2002-03-20','F',1),
    (null,'Miangaly','Kanto','2003-10-02','F',1),
    (null,'Winter','Nicky','2003-11-02','F',1),
    (null,'Andrianabo','Damien','2003-05-10','M',1),
    (null,'Christian','Mandresy','2003-06-10','M',1),
    (null,'Rahajason','Saotra','2002-10-20','F',1),
    (null,'Andriamihaja','Fabine','2001-04-20','M',1);
insert into Prof values (null,'Rakotozafy','Paul','1990-07-20','M',1),
    (null,'Rakotozafy','Jean','1980-05-20','M',1),
    (null,'Rakotomanga','Pierre','1990-12-30','M',1),
    (null,'Marie','Belle','1990-02-14','M',1),
    (null,'Rabenja','Koto','1990-01-15','M',1),
    (null,'Zara','Niavo','1990-07-20','M',1),
    (null,'Andriamanga','Nirina','1995-11-02','M',1),
    (null,'Andria','Lala','1974-02-20','M',1);
insert into Matiere values (null,'Mathématique'),
    (null,'Physique-Chimie'),
    (null,'Français'),
    (null,'Anglais'),
    (null,'S.V.T'),
    (null,'Malagasy'),
    (null,'Hisotire'),
    (null,'EPS');

insert into ProfToMatiere values (1,1);
insert into ProfToMatiere values (4,1);
insert into ProfToMatiere values (2,2);
insert into ProfToMatiere values (3,3);
insert into ProfToMatiere values (8,3);
insert into ProfToMatiere values (4,4);
insert into ProfToMatiere values (5,5);
insert into ProfToMatiere values (6,6);
insert into ProfToMatiere values (7,7);
insert into ProfToMatiere values (8,8);
-- get All Eleve from one class 
select * from Eleve where  where idClasse='%params' ;
-- get All Prof from one class 
select * from Prof where idClasse='%params' ;
-- get All Prof of one matiere 
select Prof.idProf,nom,prenom,ddn,sexe,idClasse from Prof 
    join ProfToMatiere on ProfToMatiere.idProf=Prof.idProf
    where ProfToMatiere.idMatiere=%S  ;
-- get All matiere of one prof
select Matiere.idMatiere,nom from Matiere 
    join ProfToMatiere on ProfToMatiere.idMatiere=Matiere.idMatiere
    where Matiere.idMatiere=%S  ;
-- get Emploi du temps from Classe one 
select * from EDT where idEDT in (select idEDT from Classse where idClasse='%params');
--- insert Eleve
insert into Eleve values (null,'nom','prenom','DDN','sexe','int_idClasse');
-- insert Prof
insert into Prof values (null,'nom','prenom','DDN','int_idClasse');
-- insert Matiere 
insert into Matiere values (null,'nom_matiere','int_idProf');
create table findIn(idEleve int,idProf int,nom varchar(50),prenom varchar(50),Ddn date,sexe char(2), idClasse int);
-- find
delete from findIn;
insert into findIn(idEleve,nom,prenom,ddn,sexe,idClasse)  select * from Eleve where nom like param or prenom like param
insert into findIn(idProf,nom,prenom,ddn,sexe,idClasse)  select * from Prof where nom like param or prenom like param
select * from findIn order by nom asc;
---
