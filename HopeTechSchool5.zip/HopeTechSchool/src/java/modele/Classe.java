/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;
import connection.ConnectionSQL;
import java.util.Vector;
import java.util.Date;
import java.sql.*;
/**
 *  idClasse int AUTO_INCREMENT,
    nom varchar(5),
    idEDT int,
    idEleve int,
    idProf int,
 * @author mahatoky
 */
public class Classe {
    Integer idClasse;
    String nom;
    Integer idEDT;

    public Classe() {
    }

    public Integer getIdClasse() {
        return idClasse;
    }

    public void setIdClasse(Integer idClasse) {
        this.idClasse = idClasse;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Integer getIdEDT() {
        return idEDT;
    }

    public void setIdEDT(Integer idEDT) {
        this.idEDT = idEDT;
    }

    public EDT getEDT() {
        String requet="select fileCSV from EDT where idEDT=%s ";
        requet=String.format(requet,this.getIdEDT());
        return null;
    }
            
    public Classe(Integer idClasse, String nom, Integer idEDT) {
        this.idClasse = idClasse;
        this.nom = nom;
        this.idEDT = idEDT;
        
    }
    public Eleve[] listeEleve() {
        String req="select idEleve,nom,prenom,Ddn,sexe,idClasse from Eleve where  idClasse=%s";
        req=String.format(req,this.idClasse);
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        Eleve[] eleves=null;
        try (java.sql.Statement stmt = connectionSQL.createStatement(); ResultSet res = stmt.executeQuery(req)) { 
            eleves=new Eleve[res.getRow()];
            int i=0;
            while (res.next()) {
                    Eleve eleve=new Eleve(Integer.valueOf(res.getString(1)),res.getString(2),res.getString(3),new Date(res.getString(4)),res.getString(5),String.valueOf(this.idClasse));
                    eleves[i]=eleve;
            }
            res.close();
            stmt.close();
        } catch (Exception e) {
           e.printStackTrace();
        }
        return eleves;
    }
    public void insert()  throws Exception
    {
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        try {
        String origine=this.getClass().getSimpleName();
        String requet="insert into "+origine+"("+assemblerOrg()+") values ("+assemblerVls()+")";
        System.out.print(requet+" INSERT \n");
        java.sql.Statement stmt = connectionSQL.createStatement();
        int x=stmt.executeUpdate(requet);
        stmt.close();
        connectionSQL.commit();
        } catch (Exception e) {
            connectionSQL.rollback();
            System.out.println(e.getMessage());
        }
       
    }
    public void delete()  throws Exception
    {   
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        try {
            String origine=this.getClass().getSimpleName();
            String requet="delete from "+origine +" where "+assemblerUpd();
            java.sql.Statement stmt = connectionSQL.createStatement();
            int x=stmt.executeUpdate(requet);
            stmt.close();
            connectionSQL.commit();
        } catch (Exception e) {
            connectionSQL.rollback();
            System.out.println(e.getMessage());
        }
    }
    public void find ()
    {
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        Vector vector=new Vector();
        try {
            String requet="select idClasse,nom,idEDT from Classe  where idClasse='"+this.getIdClasse().toString()+"'";
            System.out.println(requet);
            java.sql.Statement stmt = connectionSQL.createStatement();
            ResultSet res = stmt.executeQuery(requet);
            while (res.next()) {
                this.setIdClasse(Integer.valueOf(res.getString(1)));
                this.setNom(res.getString(2));
                this.setIdEDT(Integer.valueOf(res.getString(3)));
            }
            res.close();
            stmt.close();
        } catch (Exception e) {
           e.printStackTrace();
        }
    }
    String assemblerVls() throws Exception
    {
        Vector vector = new Vector<>();
        for (int i = 0; i < this.getClass().getDeclaredFields().length ; i++) {
            String retour="";
            String getMethod=this.getClass().getDeclaredFields()[i].getName().toLowerCase();
            getMethod="get"+getMethod.replaceFirst(getMethod.substring(0,1),getMethod.substring(0,1).toUpperCase());
            if( this.getClass().getMethod(getMethod).invoke(this)!=null )
            {
                retour=retour+"'"+String.valueOf(this.getClass().getMethod(getMethod).invoke(this))+"'";
                vector.add(retour);
            } 
        }
        return concact(vector.toArray());
    }
    String assemblerOrg()   throws Exception
    {
        Vector vector = new Vector<>();
        for (int i = 0; i < this.getClass().getDeclaredFields().length; i++) {
            String retour="";
            String field=this.getClass().getDeclaredFields()[i].getName().toLowerCase();
            String field2="get"+field.replaceFirst(field.substring(0,1),field.substring(0,1).toUpperCase());
            if(this.getClass().getMethod(field2).invoke(this)!=null )
            {
                retour=retour+field;
                vector.add(retour);
            } 
        }
        return concact(vector.toArray());
    }
    String concact(Object[] array)
    {
        String retour="";
        for (int i = 0; i < array.length-1; i++) {
            retour+=array[i].toString()+",";
        }
        retour+=array[array.length-1].toString();
        return  retour;
    }
    public String assemblerUpd()   throws Exception
    {
        String retour="";
        retour="ID="+this.getClass().getMethod("getId").invoke(this);
        return retour;
    }
    int count() throws Exception
    {
        int x=0;
        for (int i = 0; i < this.getClass().getDeclaredFields().length; i++) {
            String getMethod=this.getClass().getDeclaredFields()[i].getName().toLowerCase();
            getMethod="get"+getMethod.replaceFirst(getMethod.substring(0,1),getMethod.substring(0,1).toUpperCase());
            if(this.getClass().getMethod(getMethod).invoke(this)!=null) x++;
        }
        return x;
    }
    
}
