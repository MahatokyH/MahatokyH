/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import connection.ConnectionSQL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author mahatoky
 *    idProf int AUTO_INCREMENT,
    nom varchar(50),
    prenom varchar(50),
    Ddn date,
 */
public class Prof {
    Integer idProf;
    String nom;
    String prenom;
    Date Ddn;
    String sexe;
    Integer idClasse;

    
    public Prof(Integer idProf, String nom, String prenom, Date Ddn, String sexe, Integer idClasse) {
        this.idProf = idProf;
        this.nom = nom;
        this.prenom = prenom;
        this.Ddn = Ddn;
        this.sexe = sexe;
        this.idClasse = idClasse;
    }
    public Prof(Integer idProf, String nom, String prenom, Date Ddn,String sexe) {
        this.idProf = idProf;
        this.nom = nom;
        this.prenom = prenom;
        this.Ddn = Ddn;
        this.sexe=sexe;
    }
    
    public Prof() {
    }

    public Integer getIdClasse() {
        return idClasse;
    }

    public void setIdClasse(Integer idClasse) {
        this.idClasse = idClasse;
    }
    
    public String getSexe() {
        return sexe;
    }

    public void setSexe(String sexe) {
        this.sexe = sexe;
    }

    public Integer getIdProf() {
        return idProf;
    }

    public void setIdProf(Integer idProf) {
        this.idProf = idProf;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public Date getDdn() {
        return Ddn;
    }

    public void setDdn(Date Ddn) {
        this.Ddn = Ddn;
    }
    /**
     * 
     */
    public Matiere[] getMatiere(){
        String requete="select Matiere.idMatiere,nom from Matiere join ProfToMatiere on ProfToMatiere.idMatiere=Matiere.idMatiere where Matiere.idMatiere=%S  ";
        requete=String.format(requete,this.idProf);
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        Matiere[] matieres=null;
        try {
            try (java.sql.Statement stmt = connectionSQL.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY); ResultSet res = stmt.executeQuery(requete)) {
                res.last();
                matieres=new Matiere[res.getRow()];
                int i=0;
                res.beforeFirst();
                while (res.next()) {
                    Matiere matiere=new Matiere(Integer.valueOf(res.getString(1)),res.getString(2),this.idProf);
                    matieres[i]=matiere;
                }
                res.close();
                stmt.close();
            }
        } catch (Exception e) {
           e.printStackTrace();
        }
        return matieres;
    }
    public void insert()  throws Exception
    {
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        try {
        String origine=this.getClass().getSimpleName();
        String requet="insert into "+origine+"("+assemblerOrg()+") values ("+assemblerVls()+")";
        System.out.print(requet+" INSERT \n");
        java.sql.Statement stmt = connectionSQL.createStatement();
        int x=stmt.executeUpdate(requet);
        stmt.close();
        connectionSQL.commit();
        } catch (Exception e) {
            connectionSQL.rollback();
            System.out.println(e.getMessage());
        }
       
    }
    public void delete()  throws Exception
    {   
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        try {
            String origine=this.getClass().getSimpleName();
            String requet="delete from "+origine +" where idProf='"+this.getIdProf()+"'";
            java.sql.Statement stmt = connectionSQL.createStatement();
            int x=stmt.executeUpdate(requet);
            stmt.close();
            connectionSQL.commit();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void find ()
    {
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        Vector vector=new Vector();
        try {
            String requet="select idProf,nom,prenom,ddn,sexe,idClasse from Prof  where idProf="+this.getIdProf().toString();
            try (java.sql.Statement stmt = connectionSQL.createStatement(); ResultSet res = stmt.executeQuery(requet)) {
                while (res.next()) {
                    this.setIdProf(Integer.valueOf(res.getString(1)));
                    this.setNom(res.getString(2));
                    this.setPrenom(res.getString(3));
                    this.setDdn(res.getDate(4));
                    this.setSexe(res.getString(5));
                    this.setIdClasse(Integer.valueOf(res.getString(6)));
                }
                res.close();
                stmt.close();
            }
        } catch (Exception e) {
           e.printStackTrace();
        }
    }
    public void Update(String nomMethod) {
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        try {
            String update="";
            update=nomMethod+"='"+this.getClass().getMethod("get"+nomMethod).invoke(this)+"'";
            String requete="update Prof set %s where idProf=%s ";
            requete=String.format(requete,update,this.idProf);
            java.sql.Statement stmt = connectionSQL.createStatement();
            int x=stmt.executeUpdate(requete);
            stmt.close();
        } catch (Exception e) {
           e.printStackTrace();
        }
    }
    String assemblerVls() throws Exception
    {
        Vector vector = new Vector<>();
        for (int i = 0; i < this.getClass().getDeclaredFields().length ; i++) {
            String retour="";
            String getMethod=this.getClass().getDeclaredFields()[i].getName().toLowerCase();
            getMethod="get"+getMethod.replaceFirst(getMethod.substring(0,1),getMethod.substring(0,1).toUpperCase());
            if( this.getClass().getMethod(getMethod).invoke(this)!=null )
            {
                retour=retour+"'"+String.valueOf(this.getClass().getMethod(getMethod).invoke(this))+"'";
                vector.add(retour);
            } 
        }
        return concact(vector.toArray());
    }
    String assemblerOrg()   throws Exception
    {
        Vector vector = new Vector<>();
        for (int i = 0; i < this.getClass().getDeclaredFields().length; i++) {
            String retour="";
            String field=this.getClass().getDeclaredFields()[i].getName().toLowerCase();
            String field2="get"+field.replaceFirst(field.substring(0,1),field.substring(0,1).toUpperCase());
            if(this.getClass().getMethod(field2).invoke(this)!=null )
            {
                retour=retour+field;
                vector.add(retour);
            } 
        }
        return concact(vector.toArray());
    }
    String concact(Object[] array)
    {
        String retour="";
        for (int i = 0; i < array.length-1; i++) {
            retour+=array[i].toString()+",";
        }
        retour+=array[array.length-1].toString();
        return  retour;
    }
    public String assemblerUpd()   throws Exception
    {
        String retour="";
        retour="ID="+this.getClass().getMethod("getId").invoke(this);
        return retour;
    }
    int count() throws Exception
    {
        int x=0;
        for (int i = 0; i < this.getClass().getDeclaredFields().length; i++) {
            String getMethod=this.getClass().getDeclaredFields()[i].getName().toLowerCase();
            getMethod="get"+getMethod.replaceFirst(getMethod.substring(0,1),getMethod.substring(0,1).toUpperCase());
            if(this.getClass().getMethod(getMethod).invoke(this)!=null) x++;
        }
        return x;
    }
    //select * from Prof where idProf in (select idProf from Matiere where idMatiere='%params');
    public boolean matiereIsIn(Integer id)  {
        String requete="select count(*) from ProfToMatiere where idMatiere='%s' and idProf='%s'";
        requete=String.format(requete,String.valueOf(id),this.idProf);
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        
        try {
            try (java.sql.Statement stmt = connectionSQL.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY); ResultSet res = stmt.executeQuery(requete)) {
                res.next();
                if(res.getInt(1)==1){
                    return true;
                }
                res.close();
                stmt.close();
            }
        } catch (Exception e) {
           e.printStackTrace();
        }
        return false;
    }
    public void deleteMatieres() {
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        try {
            String origine=this.getClass().getSimpleName();
            String requet="delete from ProfToMatiere where idProf='"+this.getIdProf()+"'";
            java.sql.Statement stmt = connectionSQL.createStatement();
            int x=stmt.executeUpdate(requet);
            stmt.close();
            connectionSQL.commit();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
