/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import connection.ConnectionSQL;
import java.sql.ResultSet;
import java.util.Date;
import java.util.Vector;

/**
 *  idMatiere int AUTO_INCREMENT,
    nom varchar(20),
    idProf int,
 * @author mahatoky
 */
public class Matiere {
    Integer idMatiere;
    String nom;
    Integer IdProf;

    public Matiere() {
    }

    public Matiere(Integer idMatiere, String nom, Integer IdProf) {
        this.idMatiere = idMatiere;
        this.nom = nom;
        this.IdProf = IdProf;
    }

    public Integer getIdMatiere() {
        return idMatiere;
    }

    public void setIdMatiere(Integer idMatiere) {
        this.idMatiere = idMatiere;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Integer getIdProf() {
        return IdProf;
    }

    public void setIdProf(Integer IdProf) {
        this.IdProf = IdProf;
    }
    public void insert()  throws Exception
    {
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        try {
        String origine=this.getClass().getSimpleName();
        String requet="insert into "+origine+"("+assemblerOrg()+") values ("+assemblerVls()+")";
        System.out.print(requet+" INSERT \n");
        java.sql.Statement stmt = connectionSQL.createStatement();
        int x=stmt.executeUpdate(requet);
        stmt.close();
        connectionSQL.commit();
        } catch (Exception e) {
            connectionSQL.rollback();
            System.out.println(e.getMessage());
        }
       
    }
    public void delete()  throws Exception
    {   
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        try {
            String origine=this.getClass().getSimpleName();
            String requet="delete from "+origine +" where "+assemblerUpd();
            java.sql.Statement stmt = connectionSQL.createStatement();
            int x=stmt.executeUpdate(requet);
            stmt.close();
            connectionSQL.commit();
        } catch (Exception e) {
            connectionSQL.rollback();
            System.out.println(e.getMessage());
        }
    }
    public void find ()
    {
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        Vector vector=new Vector();
        try {
            String requet="select idMatiere,nom,idProf from Matiere  where idMatiere='"+this.getIdMatiere().toString()+"'";
            System.out.println(requet);
            java.sql.Statement stmt = connectionSQL.createStatement();
            ResultSet res = stmt.executeQuery(requet);
            while (res.next()) {
                this.setIdMatiere(Integer.valueOf(res.getString(1)));
                this.setIdProf(Integer.valueOf(res.getString(3)));
                this.setNom(res.getString(2));
                
            }
            res.close();
            stmt.close();
        } catch (Exception e) {
           e.printStackTrace();
        }
    }
    String assemblerVls() throws Exception
    {
        Vector vector = new Vector<>();
        for (int i = 0; i < this.getClass().getDeclaredFields().length ; i++) {
            String retour="";
            String getMethod=this.getClass().getDeclaredFields()[i].getName().toLowerCase();
            getMethod="get"+getMethod.replaceFirst(getMethod.substring(0,1),getMethod.substring(0,1).toUpperCase());
            if( this.getClass().getMethod(getMethod).invoke(this)!=null )
            {
                retour=retour+"'"+String.valueOf(this.getClass().getMethod(getMethod).invoke(this))+"'";
                vector.add(retour);
            } 
        }
        return concact(vector.toArray());
    }
    String assemblerOrg()   throws Exception
    {
        Vector vector = new Vector<>();
        for (int i = 0; i < this.getClass().getDeclaredFields().length; i++) {
            String retour="";
            String field=this.getClass().getDeclaredFields()[i].getName().toLowerCase();
            String field2="get"+field.replaceFirst(field.substring(0,1),field.substring(0,1).toUpperCase());
            if(this.getClass().getMethod(field2).invoke(this)!=null )
            {
                retour=retour+field;
                vector.add(retour);
            } 
        }
        return concact(vector.toArray());
    }
    String concact(Object[] array)
    {
        String retour="";
        for (int i = 0; i < array.length-1; i++) {
            retour+=array[i].toString()+",";
        }
        retour+=array[array.length-1].toString();
        return  retour;
    }
    public String assemblerUpd()   throws Exception
    {
        String retour="";
        retour="ID="+this.getClass().getMethod("getId").invoke(this);
        return retour;
    }
    int count() throws Exception
    {
        int x=0;
        for (int i = 0; i < this.getClass().getDeclaredFields().length; i++) {
            String getMethod=this.getClass().getDeclaredFields()[i].getName().toLowerCase();
            getMethod="get"+getMethod.replaceFirst(getMethod.substring(0,1),getMethod.substring(0,1).toUpperCase());
            if(this.getClass().getMethod(getMethod).invoke(this)!=null) x++;
        }
        return x;
    }
}
