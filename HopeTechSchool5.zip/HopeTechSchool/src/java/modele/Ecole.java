/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;
import connection.ConnectionSQL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Vector;
import modele.*;
/**
 *
 * @author mahatoky
 */
public class Ecole {
    Eleve[] eleves;
    Prof[] profs;
    Classe[] classe;
    Matiere[] matieres;
    public Eleve[] getEleves(Integer n) {
        n=(n-1)*5;
        String requet="select * from Eleve limit %s,5 ";
        requet=String.format(requet,n.toString());
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        try {
            try (java.sql.Statement stmt = connectionSQL.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY); ResultSet res = stmt.executeQuery(requet)) {
                res.last();
                this.eleves=new Eleve[res.getRow()];
                int i=0;
                res.beforeFirst();
                while (res.next()) {
                    Eleve eleve=new Eleve();
                    eleve.setIdEleve(Integer.valueOf(res.getString(1)));
                    eleve.setNom(res.getString(2));
                    eleve.setPrenom(res.getString(3));
                    eleve.setDdn(res.getDate(4));
                    eleve.setSexe(res.getString(5));
                    eleve.setIdClasse(res.getString(6));
                    this.eleves[i]=eleve;
                    i++;
                }
                res.close();
                stmt.close();
            }
        } catch (Exception e) {
           e.printStackTrace();
        }
        return this.eleves;
    }

    public Prof[] getProfs(Integer n) {
        n=(n-1)*5;
        String requet="select * from Prof limit %s,5";
        requet=String.format(requet,n.toString());
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        try {
            try (java.sql.Statement stmt = connectionSQL.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY); ResultSet res = stmt.executeQuery(requet)) {
                res.last();
                this.profs=new Prof[res.getRow()];
                int i=0;
                res.beforeFirst();
                while (res.next()) {
                    Prof prof=new Prof();
                    prof.setIdProf(Integer.valueOf(res.getString(1)));
                    prof.setNom(res.getString(2));
                    prof.setPrenom(res.getString(3));
                    prof.setDdn(res.getDate(4));
                    prof.setSexe(res.getString(5));
                    this.profs[i]=prof;
                    i++;
                }
                res.close();
                stmt.close();
            }
        } catch (Exception e) {
           e.printStackTrace();
        }
        return this.profs;
    }

    public Classe[] getClasse(Integer n) {
        n=(n-1)*5;
        String requet="select * from Classe limit %s,5";
        requet=String.format(requet,n.toString());
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        try {
            try (java.sql.Statement stmt = connectionSQL.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY); ResultSet res = stmt.executeQuery(requet)) {
                res.last();
                this.classe=new Classe[res.getRow()];
                int i=0;
                res.beforeFirst();
                while (res.next()) {
                    Classe classE=new Classe();
                    classE.setIdClasse(Integer.valueOf(res.getString(1)));
                    classE.setNom(res.getString(2));
                    classE.setIdEDT(Integer.valueOf(res.getString(3)));
                    this.classe[i]=classE;
                    i++;
                }
                res.close();
                stmt.close();
            }
        } catch (Exception e) {
           e.printStackTrace();
        }
        return this.classe;
    }

    public Matiere[] getMatieres() {
        String requet="select idMatiere,nom from Matiere ";
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        try {
            try (java.sql.Statement stmt = connectionSQL.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY); ResultSet res = stmt.executeQuery(requet)) {
                res.last();
                this.matieres=new Matiere[res.getRow()];
                int i=0;
                res.beforeFirst();
                while (res.next()) {
                    Matiere m=new Matiere();
                    m.setIdMatiere(res.getInt(1));
                    m.setNom(res.getString(2));
                    this.matieres[i]=m;
                    i++;
                }
                res.close();
                stmt.close();
            }
        } catch (Exception e) {
           e.printStackTrace();
        }
        return matieres;
    }
    public Integer nbClasse() {
        String requet="select count(*) from Classe";
        ConnectionSQL connection=new ConnectionSQL();
        Integer n=0;
        java.sql.Connection connectionSQL=connection.getConnection();
        try {
            try (java.sql.Statement stmt = connectionSQL.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY); ResultSet res = stmt.executeQuery(requet)) {
                while (res.next()) {
                    n=res.getInt(1);
                }
                res.close();
                stmt.close();
            }
        } catch (Exception e) {
           e.printStackTrace();
        }
        return n;
    }
    public Integer nbEleve() {
        String requet="select count(*) from Eleve";
        ConnectionSQL connection=new ConnectionSQL();
        Integer n=0;
        java.sql.Connection connectionSQL=connection.getConnection();
        try {
            try (java.sql.Statement stmt = connectionSQL.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY); ResultSet res = stmt.executeQuery(requet)) {
                while (res.next()) {
                    n=res.getInt(1);
                }
                res.close();
                stmt.close();
            }
        } catch (Exception e) {
           e.printStackTrace();
        }
        return n;
    }
    public Integer nbProf() {
        String requet="select count(*) from Prof";
        ConnectionSQL connection=new ConnectionSQL();
        Integer n=0;
        java.sql.Connection connectionSQL=connection.getConnection();
        try {
            try (java.sql.Statement stmt = connectionSQL.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY); ResultSet res = stmt.executeQuery(requet)) {
                while (res.next()) {
                    n=res.getInt(1);
                }
                res.close();
                stmt.close();
            }
        } catch (Exception e) {
           e.printStackTrace();
        }
        return n;
    }
}
