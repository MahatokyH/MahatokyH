/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;


import java.io.*;
import java.lang.reflect.Method;

/**
 *
 * @author mahatoky
 */
public class EDT {
    static Integer nbHeure=8;
    String fileCSVPATH;
    String[][] Lundi=new String[8][2];
    String[][] Mardi=new String[8][2];
    String[][] Mercredi=new String[8][2];
    String[][] Jeudi=new String[8][2];
    String[][] Vendredi=new String[8][2];

    public EDT(String filePath) {
        try {
            if(filePath.contentEquals(".csv")) { 
                this.fileCSVPATH=filePath;
                File file=new File(filePath);
                FileReader fileR=new FileReader(file);
                BufferedReader bfile=new BufferedReader(fileR);
                String line;
                int count=1;
                String heure;
                String matiere;
                int inCount=0;
                while((line = bfile.readLine()) !=null) {
                    if(count <= 8 ) {
                        String[] donne=line.split(";");
                        this.Lundi[inCount]=donne;
                        count++;
                        inCount++;
                    }
                    if(count > 8 && count <= 16  ) {
                        if(inCount==8) inCount=0;
                        String[] donne=line.split(";");
                        this.Mardi[inCount]=donne;
                        count++;
                        inCount++;
                    }
                    if(count > 16 && count <= 24  ) {
                         if(inCount==8) inCount=0;
                        String[] donne=line.split(";");
                        this.Mercredi[inCount]=donne;
                        count++;
                        inCount++;
                    }
                    if(count > 24 && count <= 32  ) {
                        if(inCount==8) inCount=0;
                        String[] donne=line.split(";");
                        this.Jeudi[inCount]=donne;
                        count++;
                        inCount++;
                    }
                    if(count > 32 && count <= 40  ) {
                        if(inCount==8) inCount=0;
                        String[] donne=line.split(";");
                        this.Vendredi[inCount]=donne;
                        count++;
                        inCount++;
                    }
                }
                bfile.close();
                fileR.close();
            } else {
                throw new Exception("fichier non csv");
            }
        } catch (Exception e) {
            e.getMessage();
        }
       
    }

    public String getFileCSVPATH() {
        return fileCSVPATH;
    }

    public void setFileCSVPATH(String fileCSVPATH) {
        this.fileCSVPATH = fileCSVPATH;
    }

    public static Integer getNbHeure() {
        return nbHeure;
    }

    public static void setNbHeure(Integer nbHeure) {
        EDT.nbHeure = nbHeure;
    }

    public String[][] getLundi() {
        return Lundi;
    }

    public void setLundi(String[][] Lundi) {
        this.Lundi = Lundi;
    }

    public String[][] getMardi() {
        return Mardi;
    }

    public void setMardi(String[][] Mardi) {
        this.Mardi = Mardi;
    }

    public String[][] getMercredi() {
        return Mercredi;
    }

    public void setMercredi(String[][] Mercredi) {
        this.Mercredi = Mercredi;
    }

    public String[][] getJeudi() {
        return Jeudi;
    }

    public void setJeudi(String[][] Jeudi) {
        this.Jeudi = Jeudi;
    }

    public String[][] getVendredi() {
        return Vendredi;
    }

    public void setVendredi(String[][] Vendredi) {
        this.Vendredi = Vendredi;
    }

    public void Sauvegarder() throws Exception {
        String out=new String();
        int n=0;
        String[] days={"Lundi","Mardi","Mercredi","Jeudi","Vendredi"};
        for (int day=0; day < days.length ;day++) {
            for(int i=0 ; i < nbHeure ; i++ ) 
            {
                Method in=this.getClass().getMethod("get"+days[day]);
                String[][] tmp=(String[][])in.invoke(this.getClass());
                out=out+"\n"+tmp[0]+";"+tmp[1];
            }
        }
        FileWriter files =new FileWriter(this.fileCSVPATH,false);
        BufferedWriter fichier = new BufferedWriter(files);	
	fichier.write(out);
	fichier.close();
        files.close();
    }
}
