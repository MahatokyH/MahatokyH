/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import connection.ConnectionSQL;
import java.sql.ResultSet;

/**
 *
 * @author mahatoky
 */
public class AdminSCH {
    Integer idAdmin;
    String nom;
    String mdp;
    public AdminSCH(Integer idAdmin, String nom, String mdp) {
        this.idAdmin = idAdmin;
        this.nom = nom;
        this.mdp = mdp;
    }

    public AdminSCH() {
    }

    public Integer getIdAdmin() {
        return idAdmin;
    }

    public void setIdAdmin(Integer idAdmin) {
        this.idAdmin = idAdmin;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getMdp() {
        return mdp;
    }

    public void setMdp(String mdp) {
        this.mdp = mdp;
    }
    
    public boolean isConnected() {
        String req="select count(*) from AdminSCH where nom='%s' and mdp=sha1('%s')";
        req=String.format(req,this.getNom(),this.getMdp());
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        try (java.sql.Statement stmt = connectionSQL.createStatement(); ResultSet res = stmt.executeQuery(req)) { 
            while(res.next()) {
                if(Integer.valueOf(res.getString(1))==1) return true;
            }
        } catch (Exception e) {
           return false;
        }
        return false;
    }

    public AdminSCH(String nom, String mdp) {
        this.nom = nom;
        this.mdp = mdp;
    }
}
