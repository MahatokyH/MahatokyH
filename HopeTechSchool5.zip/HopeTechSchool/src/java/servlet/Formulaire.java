/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modele.Matiere;
import service.ServiceEleve;
import service.ServiceGlobale;
import service.ServiceProf;

/**
 *
 * @author mahatoky
 */
public class Formulaire extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    ServiceGlobale serviceGBL=new ServiceGlobale();
    ServiceEleve serviceEleve=new ServiceEleve();
    ServiceProf serviceProf =new ServiceProf();
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        serviceGBL.isEleveOrIsProf(request);
        request.setAttribute("p","Formulaire");
        this.getServletContext().getRequestDispatcher("/WEB-INF/ADMIN/Template.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if(request.getParameter("isEleve")!=null) {
            FormForEleve(request,response);
        }
        else if(request.getParameter("isProf")!=null) {
            FormForProf(request,response);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    void FormForEleve (HttpServletRequest request,HttpServletResponse response)
    {
            String nom= request.getParameter("NOM") ;
            String prenom = request.getParameter("PRENOM") ;
            String sexe= request.getParameter("sexe");
            String ddn=request.getParameter("DDN") ;
            String idclasse=request.getParameter("classe") ;
            String id=request.getParameter("isEleve");
            try {
                serviceEleve.modifierEleve(id,nom, prenom, ddn, sexe, idclasse);
                serviceGBL.isEleve(request,id);
                request.setAttribute("p","Formulaire");
                this.getServletContext().getRequestDispatcher("/WEB-INF/ADMIN/Template.jsp").forward(request, response);
            } catch (Exception e) {
            
            }   
    }
    void FormForProf(HttpServletRequest request,HttpServletResponse response) {
            String nom= request.getParameter("NOM") ;
            String prenom = request.getParameter("PRENOM") ;
            String sexe= request.getParameter("sexe");
            String ddn=request.getParameter("DDN") ;
            String idclasse=request.getParameter("classe") ;
            String id=request.getParameter("isProf");
            try {
                serviceProf.modifierProf(id, nom, prenom, ddn, sexe, idclasse);
                serviceProf.insertMatieres(request,this.getServletContext(),Integer.valueOf(id));
                serviceGBL.isProf(request,id);
                request.setAttribute("p","Formulaire");
                this.getServletContext().getRequestDispatcher("/WEB-INF/ADMIN/Template.jsp").forward(request, response);
            } catch (Exception e) {
                PrintWriter out ;
                try {
                    out = response.getWriter();
                    out.println("<h1>Servlet Find at " + e.getCause() + "</h1>");
                } catch (IOException ex) {
                    Logger.getLogger(Formulaire.class.getName()).log(Level.SEVERE, null, ex);
                }
            }   
    }
    
}
