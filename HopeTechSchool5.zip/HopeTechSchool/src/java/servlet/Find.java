/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import service.*;

/**
 *
 * @author mahatoky
 */
public class Find extends HttpServlet {
    ServiceFInd find=new ServiceFInd();
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Find</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Find at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if(request.getParameter("mode")!=null && request.getParameter("mode").equals("simple")) {
            String p=request.getParameter("nom");
            request.setAttribute("ListeElevesFind",find.findSimpleEleve(p));
            request.setAttribute("ListeProfsFind",find.findSimpleProf(p));
            request.setAttribute("p","ResultFind");
            this.getServletContext().getRequestDispatcher("/WEB-INF/ADMIN/Template.jsp").forward(request,response);   
        } else {
            request.setAttribute("p","Recherche");
            this.getServletContext().getRequestDispatcher("/WEB-INF/ADMIN/Template.jsp").forward(request,response);   
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String zone=request.getParameter("zone");
        switch (zone) {
            case "E":
                request.setAttribute("ListeElevesFind",find.findElevePlus(request));
                request.setAttribute("p","ResultFind");
                request.setAttribute("test",find.condition(request));
                this.getServletContext().getRequestDispatcher("/WEB-INF/ADMIN/Template.jsp").forward(request,response);
                break;
            case "P":
                request.setAttribute("ListeProfsFind",find.findProfPlus(request));
                request.setAttribute("p","ResultFind");
                request.setAttribute("test",find.condition(request));
                this.getServletContext().getRequestDispatcher("/WEB-INF/ADMIN/Template.jsp").forward(request,response);
                break;
            default:   
                request.setAttribute("p","Recherche");
                this.getServletContext().getRequestDispatcher("/WEB-INF/ADMIN/Template.jsp").forward(request,response);
                break;
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
