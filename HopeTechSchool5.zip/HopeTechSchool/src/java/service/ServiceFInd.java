/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import connection.ConnectionSQL;
import java.sql.ResultSet;
import javax.servlet.http.HttpServletRequest;
import modele.Eleve;
import modele.Prof;

/**
 *
 * @author mahatoky
 */
public class ServiceFInd {
    Eleve[] eleves;
    Prof[] profs;
    public Eleve[] findSimpleEleve(String find)
    {
        String requet="select * from Eleve where nom like '%"+find+"%' or prenom like '%"+find+"%'limit 0,5";
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        try {
            try (java.sql.Statement stmt = connectionSQL.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY); ResultSet res = stmt.executeQuery(requet)) {
                res.last();
                eleves=new Eleve[res.getRow()];
                int i=0;
                res.beforeFirst();
                while (res.next()) {
                    Eleve eleve=new Eleve();
                    eleve.setIdEleve(Integer.valueOf(res.getString(1)));
                    eleve.setNom(res.getString(2));
                    eleve.setPrenom(res.getString(3));
                    eleve.setDdn(res.getDate(4));
                    eleve.setSexe(res.getString(5));
                    eleve.setIdClasse(res.getString(6));
                    eleves[i]=eleve;
                    i++;
                }
                res.close();
                stmt.close();
            }
        } catch (Exception e) {
           e.printStackTrace();
        }
        return eleves;
    }
    public Prof[] findSimpleProf(String find)
    {
        String requet="select * from Prof where nom like '%"+find+"%' or prenom like '%"+find+"%'limit 0,5";
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        try {
            try (java.sql.Statement stmt = connectionSQL.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY); ResultSet res = stmt.executeQuery(requet)) {
                res.last();
                profs=new Prof[res.getRow()];
                int i=0;
                res.beforeFirst();
                while (res.next()) {
                    Prof prof=new Prof();
                    prof.setIdProf(Integer.valueOf(res.getString(1)));
                    prof.setNom(res.getString(2));
                    prof.setPrenom(res.getString(3));
                    prof.setDdn(res.getDate(4));
                    prof.setSexe(res.getString(5));
                    profs[i]=prof;
                    i++;
                }
                res.close();
                stmt.close();
            }
        } catch (Exception e) {
           e.printStackTrace();
        }
        return profs;
    }

    public Eleve[] findElevePlus(HttpServletRequest request) {
        String requet="select * from Eleve "+condition(request);
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        try {
            try (java.sql.Statement stmt = connectionSQL.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY); ResultSet res = stmt.executeQuery(requet)) {
                res.last();
                eleves=new Eleve[res.getRow()];
                int i=0;
                res.beforeFirst();
                while (res.next()) {
                    Eleve eleve=new Eleve();
                    eleve.setIdEleve(Integer.valueOf(res.getString(1)));
                    eleve.setNom(res.getString(2));
                    eleve.setPrenom(res.getString(3));
                    eleve.setDdn(res.getDate(4));
                    eleve.setSexe(res.getString(5));
                    eleve.setIdClasse(res.getString(6));
                    eleves[i]=eleve;
                    i++;
                }
                res.close();
                stmt.close();
            }
        } catch (Exception e) {
           e.printStackTrace();
        }
        return eleves;
    }

    public Prof[] findProfPlus(HttpServletRequest request) {
        String requet="select * from Prof "+condition(request);
        ConnectionSQL connection=new ConnectionSQL();
        java.sql.Connection connectionSQL=connection.getConnection();
        try {
            try (java.sql.Statement stmt = connectionSQL.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY); ResultSet res = stmt.executeQuery(requet)) {
                res.last();
                profs=new Prof[res.getRow()];
                int i=0;
                res.beforeFirst();
                while (res.next()) {
                    Prof prof=new Prof();
                    prof.setIdProf(Integer.valueOf(res.getString(1)));
                    prof.setNom(res.getString(2));
                    prof.setPrenom(res.getString(3));
                    prof.setDdn(res.getDate(4));
                    prof.setSexe(res.getString(5));
                    profs[i]=prof;
                    i++;
                }
                res.close();
                stmt.close();
            }
        } catch (Exception e) {
           e.printStackTrace();
        }
        return profs;
    }
    public String condition(HttpServletRequest request)
    {
        String nom,prenom,sexe,age;
        String condition="";
        if(request.getParameter("nom")!=null && request.getParameter("nom").trim()!="") {
            nom=request.getParameter("nom");
            if(condition!="")condition=condition+"and nom like '%"+nom+"%' ";
            else condition=condition+"where nom like '%"+nom+"%' ";
        }
        if(request.getParameter("prenom")!=null && request.getParameter("prenom").trim()!="") {
            prenom=request.getParameter("prenom");
            if(condition!="")  condition=condition+"and prenom like '%"+prenom+"%' ";
            else condition=condition+"where prenom like '%"+prenom+"%' ";
        }
        if(request.getParameter("sexe")!=null && request.getParameter("sexe").trim()!="") {
            sexe=request.getParameter("sexe");
            if(condition!="") condition=condition+"and sexe like '%"+sexe+"%' ";
            else condition=condition+"where sexe='"+sexe+"' ";
        }
        if(request.getParameter("age")!=null && !"".equals(request.getParameter("age"))) {
            age=request.getParameter("age");
            if(Integer.valueOf(age)>0){
                if(condition!="") condition=condition+"and year(now())-year(ddn)="+age;
                else condition=condition+"where year(now())-year(ddn)="+age;
            }
        }
        return condition;
    }
}
