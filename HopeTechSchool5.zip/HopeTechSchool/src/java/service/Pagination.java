/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import connection.ConnectionSQL;
import java.sql.ResultSet;
import modele.Ecole;
import modele.Eleve;

/**
 *
 * @author mahatoky
 */
public class Pagination {
    Ecole ecole=new Ecole();
    Double nPageView=5.0;
    public Integer paginationEleve() {
        Double n=ecole.nbEleve().doubleValue()/nPageView;
        Integer nPage;
        if(Integer.valueOf(n.toString().split("\.")[1])>0)
        {
            nPage=Integer.valueOf(n.toString().split("\.")[0])+1;
        } else {
            nPage=Double.valueOf(n.toString()).intValue();
        }
        return nPage;
    }
    public Integer paginationClasse() {
        Double n=ecole.nbClasse().doubleValue()/nPageView;
        Integer nPage;
        if(Integer.valueOf(n.toString().split("\.")[1])>0)
        {
            nPage=Integer.valueOf(n.toString().split("\.")[0])+1;
        } else {
            nPage=Double.valueOf(n.toString()).intValue();
        }
        return nPage;
    }
    public Integer paginationProf() {
        Double n=ecole.nbProf().doubleValue()/nPageView;
        Integer nPage;
        if(Integer.valueOf(n.toString().split("\.")[1])>0)
        {
            nPage=Integer.valueOf(n.toString().split("\.")[0])+1;
        } else {
            nPage=Double.valueOf(n.toString()).intValue();
        }
        return nPage;
    }
}
