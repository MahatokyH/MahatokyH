/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import modele.AdminSCH;

/**
 *
 * @author mahatoky
 */
public class ServiceAuthentification {
    public boolean AUTHENTIFICATION(String identifiant,String mdp) {
        AdminSCH admin=new AdminSCH(identifiant,mdp);
        if(admin.isConnected()) return true;
        else return false;
    }
    public AdminSCH theAdmin(String identifiant,String mdp) {
        return new AdminSCH(identifiant,mdp);
    }
}
