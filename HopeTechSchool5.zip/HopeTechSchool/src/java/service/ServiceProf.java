/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import connection.ConnectionSQL;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import modele.Eleve;
import modele.Matiere;
import modele.Prof;

/**
 *
 * @author mahatoky
 */
public class ServiceProf {
        public void modifierProf(String id,String nom,String prenom,String ddn,String sexe,String idClasse) throws ParseException {
        //DATE : YYYY-MM-DD
        String[] dateDN=ddn.split("-");
        if(Integer.valueOf(dateDN[0])>1900 && Integer.valueOf(dateDN[1])>0 && Integer.valueOf(dateDN[1])<=12 && Integer.valueOf(dateDN[2])>0 && Integer.valueOf(dateDN[2])<=31 ) {
            Prof prof=new Prof(Integer.valueOf(id),nom,prenom,new SimpleDateFormat("YYYY-MM-DD").parse(ddn),sexe);
            try {
                prof.Update("Nom");
                prof.Update("Prenom");
                prof.Update("Ddn");
                prof.Update("Sexe");
                prof.Update("IdClasse");
            } catch (Exception ex) {
                Logger.getLogger(ServiceEleve.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    public void insertMatieres(HttpServletRequest request,ServletContext context,Integer idProf)
    {
        Prof prof=new Prof();
        prof.setIdProf(idProf);
        prof.deleteMatieres();
        Matiere[] matieres=(Matiere[]) context.getAttribute("ListeMatiere");
        for (int i = 0; i < matieres.length ; i++) {
            if(request.getParameter("matiere"+matieres[i].getIdMatiere())!=null){
                String idMatiere=request.getParameter("matiere"+matieres[i].getIdMatiere());
                String insert="insert into ProfToMatiere values('%s','%s')";
                insert=String.format(insert,matieres[i].getIdMatiere().toString(),idProf.toString());
                ConnectionSQL connection=new ConnectionSQL();
                java.sql.Connection connectionSQL=connection.getConnection();
                try {
                    java.sql.Statement stmt = connectionSQL.createStatement();
                    int x=stmt.executeUpdate(insert);
                    stmt.close();
                } catch (Exception e) {
                   e.printStackTrace();
                }
            }
        }
    } 
    public void enleverProf(String idEleve) {
        Prof prof=new Prof();
        prof.setIdProf(Integer.valueOf(idEleve));
        try {
            prof.deleteMatieres();
            prof.delete();
        } catch (Exception ex) {
            Logger.getLogger(ServiceEleve.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
