/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import modele.Eleve;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author mahatoky
 */
public class ServiceEleve {
    public void ajoutEleve(String nom,String prenom,String ddn,String sexe,String idClasse){
        //DATE : YYYY-MM-DD
        String[] dateDN=ddn.split("-");
        if(Integer.valueOf(dateDN[0])>1900 && Integer.valueOf(dateDN[1])>0 && Integer.valueOf(dateDN[1])<=12 && Integer.valueOf(dateDN[2])>0 && Integer.valueOf(dateDN[2])<=31 ) {
            Eleve eleve=new Eleve(null,nom,prenom,new Date(ddn),sexe,idClasse);
            try {
                eleve.insert();
            } catch (Exception ex) {
                Logger.getLogger(ServiceEleve.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    public void modifierEleve(String id,String nom,String prenom,String ddn,String sexe,String idClasse) throws ParseException {
        //DATE : YYYY-MM-DD
        
        String[] dateDN=ddn.split("-");
        if(Integer.valueOf(dateDN[0])>1900 && Integer.valueOf(dateDN[1])>0 && Integer.valueOf(dateDN[1])<=12 && Integer.valueOf(dateDN[2])>0 && Integer.valueOf(dateDN[2])<=31 ) {
            Eleve eleve=new Eleve(Integer.valueOf(id),nom,prenom,new SimpleDateFormat("YYYY-MM-DD").parse(ddn),sexe,idClasse);
            try {
                eleve.Update("Nom");
                eleve.Update("Prenom");
                eleve.Update("Ddn");
                eleve.Update("Sexe");
                eleve.Update("IdClasse");
            } catch (Exception ex) {
                Logger.getLogger(ServiceEleve.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    public void TransfertEleve(String idEleve,String idClasse) {
        Eleve eleve=new Eleve();
        eleve.setIdEleve(Integer.valueOf(idEleve));
        eleve.setIdClasse(idClasse);
        eleve.Update("IdClasse");
    }
    
    public void enleverEleve(String idEleve) {
        Eleve eleve=new Eleve();
        eleve.setIdEleve(Integer.valueOf(idEleve));
        try {
            eleve.delete();
        } catch (Exception ex) {
            Logger.getLogger(ServiceEleve.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
