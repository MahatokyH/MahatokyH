/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;
import connection.ConnectionSQL;
import javax.servlet.http.HttpServletRequest;
import modele.*;

/**
 *
 * @author mahatoky
 */
public class ServiceGlobale {
    Ecole ecole=new Ecole();
    public Integer[] nombreLIST()
    {
        Integer[] retour=new Integer[3];
        retour[0]=ecole.nbClasse();
        retour[1]=ecole.nbProf();
        retour[2]=ecole.nbEleve();
        return retour;
    }
    public Eleve[] viewListeElves(int nb) {
        return ecole.getEleves(1);
    }
    public Prof[] viewListeProf(int nb) {
        return ecole.getProfs(1);
    }
    public Classe[] viewListeClasses(int nb) {
        return ecole.getClasse(1);
    }
    public Matiere[] viewMatiere() {
        return ecole.getMatieres();
    }
    public void isEleveOrIsProf(HttpServletRequest request) {
        if(request.getParameter("idProf")!=null && Integer.valueOf(request.getParameter("idProf").toString())>0) {
            request.setAttribute("isProf",true);
            request.setAttribute("isEleve",false);
            Prof prof=new Prof();
            prof.setIdProf(Integer.valueOf(request.getParameter("idProf").toString()));
            prof.find();
            request.setAttribute("PersonneToModif",prof);
        } else if (request.getParameter("idEleve")!=null && Integer.valueOf(request.getParameter("idEleve").toString())>0) {
            request.setAttribute("isProf",false);
            request.setAttribute("isEleve", true);
            Eleve eleve=new Eleve();
            eleve.setIdEleve(Integer.valueOf(request.getParameter("idEleve").toString()));
            eleve.find();
            request.setAttribute("PersonneToModif",eleve);
        }
    }
    public void isEleve(HttpServletRequest request,String id) {
        request.setAttribute("isProf",false);
        request.setAttribute("isEleve", true);
        Eleve eleve=new Eleve();
        eleve.setIdEleve(Integer.valueOf(id));
        eleve.find();
        request.setAttribute("PersonneToModif",eleve);
    }
    public void isProf(HttpServletRequest request,String id) {
            request.setAttribute("isProf",true);
            request.setAttribute("isEleve",false);
            Prof prof=new Prof();
            prof.setIdProf(Integer.valueOf(id));
            prof.find();
            request.setAttribute("PersonneToModif",prof);
    }
}
