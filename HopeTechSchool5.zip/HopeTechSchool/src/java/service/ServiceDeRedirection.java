/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import java.io.IOException;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modele.Ecole;

/**
 *
 * @author mahatoky
 */
public class ServiceDeRedirection {
    Ecole ecole=new Ecole();
    Pagination pagination=new Pagination();
    public void redirectionPageTemplateTable(HttpServletRequest request, HttpServletResponse response,ServletContext context) throws ServletException, IOException {
        request.setAttribute("p","TemplateForTable");
        if("classe".equals(request.getParameter("viewFor"))) {
            request.setAttribute("views",ecole.getClasse(1));
            request.setAttribute("nPage",pagination.paginationClasse());
            request.setAttribute("numeroPage",1);
            context.getRequestDispatcher("/WEB-INF/ADMIN/Template.jsp?viewFor=classe").forward(request, response);
        }
        if("professeur".equals(request.getParameter("viewFor"))) {
            request.setAttribute("views",ecole.getProfs(1));
            request.setAttribute("nPage",pagination.paginationProf());
            request.setAttribute("numeroPage",1);
            context.getRequestDispatcher("/WEB-INF/ADMIN/Template.jsp?viewFor=professeur").forward(request, response);
        }
        if("eleve".equals(request.getParameter("viewFor"))) {
            request.setAttribute("views",ecole.getEleves(1));
            request.setAttribute("nPage",pagination.paginationEleve());
            request.setAttribute("numeroPage",1);
            context.getRequestDispatcher("/WEB-INF/ADMIN/Template.jsp?viewFor=eleve").forward(request, response);
        }
    }
    public void redirectionPageTemplateTable(HttpServletRequest request, HttpServletResponse response,ServletContext context,Integer nbPage) throws ServletException, IOException {
        request.setAttribute("p","TemplateForTable");
        if("classe".equals(request.getParameter("viewFor"))) {
            request.setAttribute("views",ecole.getClasse(nbPage));
            request.setAttribute("nPage",pagination.paginationClasse());
            request.setAttribute("numeroPage",nbPage);
            context.getRequestDispatcher("/WEB-INF/ADMIN/Template.jsp?viewFor=classe").forward(request, response);
        }
        if("professeur".equals(request.getParameter("viewFor"))) {
            request.setAttribute("views",ecole.getProfs(nbPage));
            request.setAttribute("nPage",pagination.paginationProf());
            request.setAttribute("numeroPage",nbPage);
            context.getRequestDispatcher("/WEB-INF/ADMIN/Template.jsp?viewFor=professeur").forward(request, response);
        }
        if("eleve".equals(request.getParameter("viewFor"))) {
            request.setAttribute("views",ecole.getEleves(nbPage));
            request.setAttribute("nPage",pagination.paginationEleve());
            request.setAttribute("numeroPage",nbPage);
            context.getRequestDispatcher("/WEB-INF/ADMIN/Template.jsp?viewFor=eleve").forward(request, response);
        }
    }
}
